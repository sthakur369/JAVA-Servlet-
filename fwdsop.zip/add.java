import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
@WebServlet(name = "/add")
public class add extends HttpServlet {


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter pw=response.getWriter();
        String title=request.getParameter("bt");
        String author=request.getParameter("ba");
        String publisher=request.getParameter("bp");
        String id=request.getParameter("bi");

        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/s080","root","password");

            String query="insert into books values(?,?,?,?);";
            PreparedStatement p=con.prepareStatement(query);
            p.setString(1,title);
            p.setString(2,author);
            p.setString(3,publisher);
            p.setString(4,id);

            int t=p.executeUpdate();
            Statement stmt;
            stmt = con.createStatement();


            pw.print("<table width=50% border=1 bgcolor=\"#f1f1f1\">");
            pw.print("<H1>BOOKS</H1>");
            ResultSet rs;
            rs=stmt.executeQuery("SELECT * FROM books");
            ResultSetMetaData rsmd=rs.getMetaData();
            int total=rsmd.getColumnCount();
            pw.print("<tr>");
            for(int i=1;i<=total;i++)
            {
                pw.print("<th>"+rsmd.getColumnName(i)+"</th>");
            }

            pw.print("</tr>");
            while(rs.next())
            {
                pw.print("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+" </td><td>" +rs.getString(3)+"</td><td>"+rs.getString(4)+"</td></tr>");

            }

            pw.print("</table>");

            if(t==0)
            {
                pw.println("<b><h1><u>ADDITION OF BOOK IS FAILED !!</u></h1></b>");
                pw.println("<a href=\"h.html\" >Go Back</a>");
            }
            else
            {
                pw.println("<b><h1><u>BOOK IS ADDED !!</u></h1></b>");
                pw.println("<a href=\"LibraryHome.html\" >Go Back</a>");
            }
            con.close();
        }catch(Exception e){ System.out.println(e);}
    }
}

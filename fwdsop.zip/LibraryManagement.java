import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet(name="/Servlet")
public class LibraryManagement extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter pw=response.getWriter();
        int t=0;


        String username =request.getParameter("un");
        String password=request.getParameter("pw");

        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/s080","root","password");
//here s080 is database name, root is username and password is password

            PreparedStatement p=con.prepareStatement("select * from loginlm");
            ResultSet rs;
            rs=p.executeQuery();
            while(rs.next())
            {
                String a=rs.getString("username");
                String b=rs.getString("password");
                if(username.equals(a) && password.equals(b))
                {
                    t=1;
                }

            }
            if(t==1)
                response.sendRedirect("LibraryHome.html");
            else
                pw.println("<b>wrong Username or Password Try Again !!</b>");
            con.close();
        }catch(Exception e){ System.out.println(e);}
    }
}









